const localizeHtmlPage = () => {
  document.querySelectorAll('[data-i18n]').forEach(elem => {
    elem.textContent = chrome.i18n.getMessage(elem.getAttribute('data-i18n'));
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(elem => {
    elem.placeholder = chrome.i18n.getMessage(elem.getAttribute('data-i18n-placeholder'));
  });
  document.querySelectorAll('[data-i18n-title]').forEach(elem => {
    elem.title = chrome.i18n.getMessage(elem.getAttribute('data-i18n-title'));
  });
};
localizeHtmlPage();

const rulesContainer = document.querySelector("#rulesContainer");
const ruleTemplate = document.querySelector("#ruleTemplate");
const noRuleRow = rulesContainer.querySelector(".no-item-row");

const saveRules = () => {
  const rows = rulesContainer.querySelectorAll(".rule-row:not(#ruleTemplate)");
  const rules = [...rows].map(row => {
    return {
      id: Number(row.dataset.id),
      type: row.querySelector(".rule-type").dataset.type,
      text: row.querySelector(".rule-text").textContent,
      active: row.querySelector(".rule-active-checkbox").checked
    }
  });
  chrome.storage.local.set({ rules: rules });
};

const createRuleRow = (id, type, word, active = true) => {
  const row = ruleTemplate.cloneNode(true);

  const typeContent = {
    "contains": chrome.i18n.getMessage("ruleTypeContains"),
    "equals": chrome.i18n.getMessage("ruleTypeEquals"),
    "regexp": chrome.i18n.getMessage("ruleTypeRegexp")
  }[type];

  row.id = "";
  row.dataset.id = id,
  row.querySelector(".rule-type").textContent = typeContent;
  row.querySelector(".rule-type").dataset.type = type;
  row.querySelector(".rule-text").textContent = word;
  const activeCheckbox = row.querySelector(".rule-active-checkbox");
  activeCheckbox.checked = active;

  const updateStateUI = () => {
    if (activeCheckbox.checked) {
      row.style.opacity = "1";
    } else {
      row.style.opacity = "0.5";
    }
  };

  updateStateUI();

  activeCheckbox.addEventListener("change", () => {
    updateStateUI();
    saveRules();
  });

  row.style.display = "table-row";

  const deleteBtn = row.querySelector(".delete-btn");
  deleteBtn.addEventListener("click", () => {
    rulesContainer.removeChild(row);
    saveRules();
    if (rulesContainer.querySelectorAll(".rule-row:not(#ruleTemplate)").length === 0) {
      noRuleRow.classList.remove("is-hidden");
    }
  });

  rulesContainer.prepend(row);
  noRuleRow.classList.add("is-hidden");
}

const addRule = () => {
  const inputType = document.querySelector(".input-rule-type");
  const inputText = document.querySelector(".input-rule-text");

  if (!inputText.value) {
    inputText.classList.add("is-danger");
    inputText.focus();
    return;
  }

  const id = (new Date()).getTime();
  createRuleRow(id, inputType.value, inputText.value, true);
  saveRules();

  inputText.classList.remove("is-danger");
  inputType.value = "contains";
  inputText.value = "";
  inputText.focus();
}

document.querySelector("#addBtn").addEventListener("click", addRule);

document.querySelector(".vc-switch-input").addEventListener("change", event => {
  const checked = event.target.checked ? "on" : "off";
  chrome.storage.local.set({ power: checked });
});

document.querySelector(".input-rule-text").addEventListener("keypress", event => {
  if (event.key === "Enter") {
    addRule();
  }
});

(async () => {
  const { power, rules } = await chrome.storage.local.get(["power", "rules"]);
  
  const currentPower = power || "on";
  const powerSwitch = document.querySelector(".vc-switch-input");
  powerSwitch.checked = currentPower === "on";

  if (rules && rules.length !== 0) {
    rules.sort((a, b) => a.id - b.id).forEach((rule) => createRuleRow(rule.id, rule.type, rule.text, rule.active !== false));
  }
})();
